"""PC regression tests for zvei_decoder.py alpha 1.4 (never goes on the phone).

Run from anywhere:  python tests/test_zvei.py
Compares the new decoder against the untouched alpha 1.3 baseline and checks
the new features. Reports PC results only; nothing here is a phone test.
"""
import ast
import builtins
import hashlib
import importlib.util
import os
import sys
import tempfile
import types

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import gen_fixtures as gf  # noqa: E402

NEW_PATH = os.path.join(ROOT, 'zvei_decoder.py')
OLD_PATH = os.path.join(ROOT, 'baseline', 'zvei_decoder_alpha13.py')
REF_PATH = os.path.join(ROOT, 'reference_audio', 'zvei.wav')
FIX_DIR = os.path.join(HERE, 'fixtures')

REF_OFFSETS = [2.08, 2.68, 3.22, 3.75, 4.28, 4.82, 5.35]

RESULTS = []


def check(name, ok, detail=''):
    RESULTS.append((name, bool(ok), detail))
    print('%s  %s%s' % ('PASS' if ok else 'FAIL', name,
                        ('  -- ' + detail) if detail else ''))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        h.update(f.read())
    return h.hexdigest()


# ------------------------------------------------------------------ scanner
BAD_CALLS = ('sum', 'enumerate', 'set', 'frozenset', 'sorted', 'reversed',
             'any', 'all', 'bytearray', 'bytes', 'format', 'next', 'iter_',
             'isinstance_')
BAD_ATTRS = ('format', 'partition', 'rpartition', 'bit_length', 'format_map',
             'startswith_')


def py22_scan(path):
    """Crude AST scan for constructs that Python 2.2.2 cannot run."""
    with open(path, 'r', encoding='utf-8') as f:
        tree = ast.parse(f.read())
    problems = []
    for node in ast.walk(tree):
        line = getattr(node, 'lineno', 0)
        kind = type(node).__name__
        if kind in ('ListComp', 'GeneratorExp', 'SetComp', 'DictComp', 'IfExp',
                    'With', 'AsyncWith', 'JoinedStr', 'AnnAssign',
                    'AsyncFunctionDef', 'Set', 'Starred', 'Nonlocal',
                    'Yield', 'YieldFrom', 'NamedExpr', 'Await', 'Match'):
            problems.append('%s at line %d' % (kind, line))
        if kind in ('FunctionDef', 'ClassDef') and node.decorator_list:
            problems.append('decorator at line %d' % line)
        if kind == 'Try' and node.handlers and node.finalbody:
            problems.append('try/except/finally at line %d' % line)
        if kind == 'ExceptHandler' and node.name:
            problems.append('except ... as at line %d' % line)
        if kind == 'Call':
            f = node.func
            if isinstance(f, ast.Name) and f.id in BAD_CALLS:
                problems.append('%s() at line %d' % (f.id, line))
            if isinstance(f, ast.Name) and f.id in ('max', 'min'):
                if node.keywords:
                    problems.append('%s(key=) at line %d' % (f.id, line))
            if isinstance(f, ast.Name) and f.id == 'print':
                if len(node.args) != 1 or node.keywords:
                    problems.append('print() form at line %d' % line)
            if isinstance(f, ast.Attribute) and f.attr in BAD_ATTRS:
                problems.append('.%s() at line %d' % (f.attr, line))
        if kind == 'Constant' and isinstance(node.value, bytes):
            problems.append('bytes literal at line %d' % line)
        if kind == 'Name' and node.id in ('nonlocal', 'None_'):
            pass
    return problems


# ------------------------------------------------------------ helper paths
def run(mod, path, tone_ms=40):
    bursts, dur, rate = mod.decode_file(path, tone_ms)
    return (bursts, list(mod.LAST_SIGNAL_LOG),
            [list(b) for b in mod.LAST_BURST_DIAGNOSTICS])


def same_decode(old, new):
    """decode() output and the first 12 fields of every diagnostic match."""
    ob, ol, od = old
    nb, nl, nd = new
    if ob != nb:
        return False, 'bursts differ'
    if len(ol) != len(nl):
        return False, 'signal log length differs'
    for a, b in zip(ol, nl):
        if tuple(a[:12]) != tuple(b[:12]):
            return False, 'signal log entry differs'
    if len(od) != len(nd):
        return False, 'burst diagnostics count differs'
    for x, y in zip(od, nd):
        if len(x) != len(y):
            return False, 'burst diagnostic length differs'
        for a, b in zip(x, y):
            if tuple(a[:12]) != tuple(b[:12]):
                return False, 'burst diagnostic entry differs'
    return True, ''


def main():
    ref_sha_before = sha(REF_PATH)
    new = load(NEW_PATH, 'zvei_new')
    old = load(OLD_PATH, 'zvei_old')

    # 1. syntax + Python 2.2 construct scan
    import py_compile
    py_compile.compile(NEW_PATH, doraise=True,
                       cfile=os.path.join(tempfile.gettempdir(), 'zn.pyc'))
    base_problems = py22_scan(OLD_PATH)
    new_problems = py22_scan(NEW_PATH)
    check('scanner sanity: alpha 1.3 baseline passes its own scan',
          not base_problems, '; '.join(base_problems[:5]))
    check('Py2.2 construct scan of new source', not new_problems,
          '; '.join(new_problems[:8]))

    # 2. reference WAV, fixed 40 ms
    nb, nl, nd = run(new, REF_PATH, 40)
    check('reference: seven 186 bursts, exact offsets',
          [(round(t, 2), s) for t, s in nb] ==
          [(t, '186') for t in REF_OFFSETS],
          str([(round(t, 2), s) for t, s in nb]))
    ok, why = same_decode(run(old, REF_PATH, 40), (nb, nl, nd))
    check('reference: decode output and diagnostics identical to alpha 1.3',
          ok, why)
    first = [x for x in nl if x[0] < 2.3]
    one = [x for x in first if x[2] == '1' and x[8]]
    nine = [x for x in first if x[2] == '9']
    check('reference: first real 1 accepted', len(one) == 1)
    check('reference: leading false 9 rejected',
          len(nine) >= 1 and all(not x[8] for x in nine))

    # 3. synthetic fixtures: new == old, and correct decode
    gf.standard_fixtures(FIX_DIR)
    exp = {
        'clean_186x3.wav': (40, ['186'] * 3),
        'five_tone_calls.wav': (40, ['12345', '90817', '26485', '73951']),
        'e_repeat.wav': (40, ['12E45']),
        'group_gaps.wav': (40, ['186'] * 5 + ['123']),
        'dur_30.wav': (30, ['13579', '02468']),
        'dur_50.wav': (50, ['13579', '02468']),
        'dur_70.wav': (70, ['13579', '02468']),
        'dur_100.wav': (100, ['13579', '02468']),
        'jitter_amp.wav': (40, ['12345', '67890']),
        'offset_plus1.wav': (40, ['12345', '67890']),
        'offset_minus15.wav': (40, ['12345', '67890']),
        'many_runs.wav': (40, None),
        'quiet.wav': (40, ['186', '186']),
        'clipped.wav': (40, ['186', '186']),
    }
    for name in sorted(exp):
        ms, want = exp[name]
        p = os.path.join(FIX_DIR, name)
        o = run(old, p, ms)
        n = run(new, p, ms)
        ok, why = same_decode(o, n)
        check('%s: identical to alpha 1.3 at %d ms' % (name, ms), ok, why)
        if want is not None:
            got = [s for t, s in n[0]]
            check('%s: decoded as expected at %d ms' % (name, ms),
                  got == want, 'got %s' % got)

    # 4. E marker unchanged: raw vs expanded kept separate
    nb, _, _ = run(new, os.path.join(FIX_DIR, 'e_repeat.wav'), 40)
    raw = nb[0][1]
    check('E: raw sequence kept', raw == '12E45', raw)
    check('E: expanded display sequence', new._expand_repetition(raw) == '12245')
    check('E: flat format shows raw note',
          '(raw: 12E45)' in new.format_result(nb, False))
    check('E: collapsed format shows raw note',
          '(raw: 12E45)' in new.format_result(nb))

    # 5. grouping
    nb, _, _ = run(new, REF_PATH, 40)
    g = new.group_bursts(nb)
    check('group: reference collapses to one x7 group',
          len(g) == 1 and g[0][3] == 7 and round(g[0][0], 2) == 2.08 and
          round(g[0][1], 2) == 5.35)
    text = new.format_result(nb)
    check('group: reference text', text.startswith('2.08-5.35s  186 x7'), text)
    nb2, _, _ = run(new, os.path.join(FIX_DIR, 'group_gaps.wav'), 40)
    g2 = new.group_bursts(nb2)
    check('group: gap > 3 s splits, different ID splits',
          [(x[2], x[3]) for x in g2] == [('186', 3), ('186', 2), ('123', 1)],
          str([(x[2], x[3]) for x in g2]))
    check('group: decode() itself still returns every burst',
          len(nb2) == 6)

    # 6. the removed name-lookup feature must really be gone
    check('names: KNOWN_IDS / tags removed',
          not hasattr(new, 'KNOWN_IDS') and not hasattr(new, '_name_tag') and
          'UNKNOWN' not in new.format_result(
              run(new, os.path.join(FIX_DIR, 'five_tone_calls.wav'), 40)[0]))

    # 7. level warning
    ref_lv = new.analyze_level(new.read_wav(REF_PATH)[0])
    check('level: reference gets no warning', ref_lv[2] == '', str(ref_lv))
    q = new.analyze_level(new.read_wav(os.path.join(FIX_DIR, 'quiet.wav'))[0])
    check('level: quiet recording -> LOW LEVEL', q[2].startswith('LOW'), str(q))
    c = new.analyze_level(new.read_wav(os.path.join(FIX_DIR, 'clipped.wav'))[0])
    check('level: clipped recording -> CLIPPING', c[2].startswith('CLIPPING'),
          str(c))
    n_ok = new.analyze_level(new.read_wav(
        os.path.join(FIX_DIR, 'clean_186x3.wav'))[0])
    check('level: normal synthetic recording -> no warning', n_ok[2] == '',
          str(n_ok))

    # 8. frequency offset accuracy (informational estimate, bounded error)
    import numpy as np
    errors = []
    for off in (-1.5, -1.0, -0.5, 0.0, 0.5, 1.0):
        for seq in ('13579', '02468', 'ABCDF'):
            x = gf.recording([(1.0, seq)], 3.0, offset_pct=off)
            p = os.path.join(FIX_DIR, '_off.wav')
            gf.write_wav(p, x)
            nb, _, _ = run(new, p, 40)
            if len(nb) != 1 or nb[0][1] != seq:
                errors.append((off, seq, None))
                continue
            errors.append((off, seq, new.LAST_BURST_OFFSETS[0][0] - off))
    os.remove(os.path.join(FIX_DIR, '_off.wav'))
    bad = [e for e in errors if e[2] is None]
    vals = [abs(e[2]) for e in errors if e[2] is not None]
    check('freq offset: every offset case still decodes', not bad, str(bad))
    check('freq offset: mean abs error <= 0.4 %%, max <= 0.9 %%',
          vals and np.mean(vals) <= 0.4 and max(vals) <= 0.9,
          'mean %.2f%% max %.2f%% over %d cases' % (np.mean(vals), max(vals),
                                                    len(vals)))
    check('freq offset: reference reads about 0 (|x| < 0.5 %)',
          abs(new.LAST_BURST_OFFSETS[0][0]) < 0.5 if run(new, REF_PATH, 40)
          else False, str(new.LAST_BURST_OFFSETS[:1]))

    # 9. caps
    nb, nl, nd = run(new, os.path.join(FIX_DIR, 'many_runs.wav'), 40)
    check('cap: signal log limited to 100 with more runs available',
          len(new.LAST_SIGNAL_LOG) == 100 and len(nb) == 32,
          'log %d, bursts %d' % (len(new.LAST_SIGNAL_LOG), len(nb)))
    new.CALL_HISTORY[:] = []
    new.LAST_BURST_OFFSETS[:] = []
    many = [(float(i * 10), '%03d' % i) for i in range(120)]
    new._add_to_history(many, 1.7e9, 40, 10.0, 8000)
    check('cap: call history limited to 50, newest first',
          len(new.CALL_HISTORY) == 50 and new.CALL_HISTORY[0][2] == '119',
          'len %d first %s' % (len(new.CALL_HISTORY), new.CALL_HISTORY[0][2]))
    new.CALL_HISTORY[:] = []
    flood = [(float(i * 0.5), '186') for i in range(60)]
    new._add_to_history(flood, 1.7e9, 40, 10.0, 8000)
    check('cap: 60 rapid identical bursts become one history entry',
          len(new.CALL_HISTORY) == 1 and new.CALL_HISTORY[0][8] == 60)
    new.CALL_HISTORY[:] = []

    # 10. no disk writes during decode/format/history
    opened = []
    real_open = builtins.open

    def spy(file, mode='r', *a, **k):
        if any(ch in mode for ch in 'wax+'):
            opened.append((str(file), mode))
        return real_open(file, mode, *a, **k)

    before = sorted(os.listdir(FIX_DIR))
    builtins.open = spy
    try:
        b, d, r = new.decode_file(REF_PATH, 40)
        new.format_result(b)
        new._add_to_history(b, 1.7e9, 40, d, r)
    finally:
        builtins.open = real_open
    after = sorted(os.listdir(FIX_DIR))
    check('no disk: no write-mode open during decode/format/history',
          not opened and before == after, str(opened))
    new.CALL_HISTORY[:] = []

    # 11. source contains the processing-stage labels
    src = open(NEW_PATH, encoding='utf-8').read()
    labels = ['STOPPING RECORDING', 'RECORDING STOPPED', 'CLOSING WAV',
              'WAV READY', 'READING WAV', 'DECODING', 'DECODING %d%%']
    missing = [s for s in labels if s not in src]
    check('status labels present in source', not missing, str(missing))
    check('default tone length still 40 ms', new.DEFAULT_TONE_MS == 40)
    check('ZVEI-1 table identical to alpha 1.3', new.ZVEI1 == old.ZVEI1)
    check('thresholds identical to alpha 1.3',
          (new.FRAME_MIN_PURITY, new.FRAME_MIN_MATCH, new.RUN_MIN_PURITY,
           new.RUN_MIN_MATCH, new.FREQ_LOW_TOL, new.FREQ_HIGH_TOL) ==
          (old.FRAME_MIN_PURITY, old.FRAME_MIN_MATCH, old.RUN_MIN_PURITY,
           old.RUN_MIN_MATCH, old.FREQ_LOW_TOL, old.FREQ_HIGH_TOL))

    # 12. phone UI code paths with stub PyS60 modules
    ui_tests(ref_sha_before)

    check('reference WAV unmodified (sha256)', sha(REF_PATH) == ref_sha_before)

    failed = [r for r in RESULTS if not r[1]]
    print('\n%d checks, %d passed, %d failed' %
          (len(RESULTS), len(RESULTS) - len(failed), len(failed)))
    return 1 if failed else 0


def ui_tests(ref_sha_before):
    """Exercise the phone-side UI functions with fake appuifw/e32/audio."""
    builtins.unicode = str

    titles = []
    notes = []
    menu_replies = []

    class App(object):
        def __setattr__(self, key, value):
            if key == 'title':
                titles.append(value)
            object.__setattr__(self, key, value)

    appuifw = types.ModuleType('appuifw')
    appuifw.app = App()
    appuifw.note = lambda text, kind='info': notes.append((text, kind))
    appuifw.popup_menu = lambda labels, title=None: (
        menu_replies.pop(0) if menu_replies else None)
    appuifw.query = lambda *a, **k: True
    e32 = types.ModuleType('e32')
    e32.ao_yield = lambda: None
    e32.ao_sleep = lambda s: None
    audio = types.ModuleType('audio')

    class Snd(object):
        def record(self):
            pass

        def stop(self):
            pass

        def close(self):
            pass

    audio.Sound = types.SimpleNamespace(open=lambda p: Snd())
    saved_mods = {}
    for name, mod in (('appuifw', appuifw), ('e32', e32), ('audio', audio)):
        saved_mods[name] = sys.modules.get(name)
        sys.modules[name] = mod
    try:
        ui = load(NEW_PATH, 'zvei_ui')   # ON_PHONE True; main() exits at once
        check('ui: module loads with phone stubs and main() exits cleanly',
              ui.ON_PHONE)

        ui._decode_ui(REF_PATH, 40, 1.7e9)
        text = notes[-1][0]
        check('ui: result shows collapsed x7',
              '186 x7' in text, text.replace('\n', ' | '))
        check('ui: result shows level line', 'Level: peak' in text)
        check('ui: history has one entry with count 7',
              len(ui.CALL_HISTORY) == 1 and ui.CALL_HISTORY[0][8] == 7)
        check('ui: stage labels shown while decoding',
              'READING WAV' in titles and 'DECODING' in titles and
              'DECODING 100%' in titles)

        menu_replies.append(0)
        ui._show_history()
        details = notes[-1][0]
        check('ui: history details show repeats, freq offset, level',
              'Repeats: 7 bursts' in details and
              'Freq offset:' in details and 'Level: peak' in details,
              details.replace('\n', ' | ')[:200])

        ui._show_decoder_info(40, 10)
        check('ui: decoder info shows version and level',
              'alpha 1.4' in notes[-1][0] and 'Last level' in notes[-1][0])

        del titles[:]
        ui._record(os.path.join(tempfile.gettempdir(), 'zvei_stub.wav'), 1)
        seq = [t for t in titles if t in ('STOPPING RECORDING',
                                          'RECORDING STOPPED', 'CLOSING WAV',
                                          'WAV READY')]
        check('ui: recording cleanup labels in order',
              seq == ['STOPPING RECORDING', 'RECORDING STOPPED',
                      'CLOSING WAV', 'WAV READY'], str(seq))
    finally:
        for name, mod in saved_mods.items():
            if mod is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = mod


if __name__ == '__main__':
    sys.exit(main())
