"""PC-only noise-margin sweep for the ZVEI decoder (informational, not a gate).

Adds noise to the reference recording and to synthetic calls at stepped SNR
and reports how many calls decode exactly and how many wrong/extra bursts
appear. SNR = in-tone RMS / noise RMS. Never modifies the reference WAV.

Usage: python tests/noise_sweep.py [seeds]
"""
import importlib.util
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import gen_fixtures as gf  # noqa: E402

SNRS = [30, 20, 15, 12, 9, 6, 3, 0]
REF_TRUTH = [2.08, 2.68, 3.22, 3.75, 4.28, 4.82, 5.35]
SYN_CALLS = [(1.0, '12345'), (3.0, '90817'), (5.0, '26485'), (7.0, '73951')]


def load_decoder():
    spec = importlib.util.spec_from_file_location(
        'zvei_new', os.path.join(ROOT, 'zvei_decoder.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def to_ints(x):
    return np.clip(np.round(x * 32767.0), -32768, 32767).astype(int).tolist()


def tone_rms(x, starts, length_s):
    parts = []
    for s in starts:
        i = int(s * gf.RATE)
        parts.append(x[i:i + int(length_s * gf.RATE)])
    seg = np.concatenate(parts)
    return float(np.sqrt(np.mean(seg * seg)))


def score(bursts, truth):
    """truth: list of (start_s, raw). Returns (exact, wrong_or_extra)."""
    used = set()
    exact = 0
    for t, raw in truth:
        for k, (bt, braw) in enumerate(bursts):
            if k not in used and abs(bt - t) <= 0.15 and braw == raw:
                used.add(k)
                exact += 1
                break
    return exact, len(bursts) - len(used)


def job(args):
    scenario, snr, seed = args
    dec = load_decoder()
    if scenario in ('ref+white', 'ref+band'):
        x = gf.read_wav_float(os.path.join(ROOT, 'reference_audio', 'zvei.wav'))
        truth = [(t, '186') for t in REF_TRUTH]
        rms = tone_rms(x, REF_TRUTH, 0.12)
        if scenario == 'ref+white':
            x = gf.add_white_noise(x, snr, rms, seed)
        else:
            x = gf.add_band_noise(x, snr, rms, seed)
    else:
        x = gf.recording(SYN_CALLS, 10.0)
        truth = SYN_CALLS
        rms = tone_rms(x, [c[0] for c in SYN_CALLS], 0.2)
        x = gf.add_band_noise(x, snr, rms, seed)
    t0 = time.time()
    bursts = dec.decode(to_ints(x), gf.RATE, 40)
    elapsed = time.time() - t0
    exact, bad = score(bursts, truth)
    return scenario, snr, seed, exact, len(truth), bad, elapsed


def main():
    seeds = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    scenarios = ['ref+white', 'ref+band', 'syn+band']
    jobs = [(s, snr, seed) for s in scenarios for snr in SNRS
            for seed in range(seeds)]
    pool = Pool(2)
    try:
        results = pool.map(job, jobs, chunksize=4)
    finally:
        pool.close()
        pool.join()

    lines = ['# Noise-margin sweep (PC, informational)', '',
             'SNR = in-tone RMS / noise RMS. %d random seeds per cell. '
             'Cell = exact calls found / truth calls (total over seeds), '
             'then wrong-or-extra bursts. Fixed 40 ms setting, default '
             'thresholds.' % seeds, '']
    longest = 0.0
    for scenario in scenarios:
        lines.append('## %s' % scenario)
        lines.append('')
        lines.append('| SNR dB | exact / truth | wrong or extra bursts |')
        lines.append('|---:|---:|---:|')
        for snr in SNRS:
            rows = [r for r in results if r[0] == scenario and r[1] == snr]
            exact = sum(r[3] for r in rows)
            total = sum(r[4] for r in rows)
            bad = sum(r[5] for r in rows)
            longest = max(longest, max(r[6] for r in rows))
            lines.append('| %d | %d / %d (%.0f%%) | %d |' %
                         (snr, exact, total, 100.0 * exact / total, bad))
        lines.append('')
    lines.append('Slowest single decode on this PC: %.1f s (pure Python; the '
                 'N95 is far slower).' % longest)
    text = '\n'.join(lines)
    print(text)
    with open(os.path.join(HERE, 'noise_sweep_results.md'), 'w') as f:
        f.write(text + '\n')


if __name__ == '__main__':
    main()
