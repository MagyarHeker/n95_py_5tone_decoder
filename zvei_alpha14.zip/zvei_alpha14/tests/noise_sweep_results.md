# Noise-margin sweep (PC, informational)

SNR = in-tone RMS / noise RMS. 8 random seeds per cell. Cell = exact calls found / truth calls (total over seeds), then wrong-or-extra bursts. Fixed 40 ms setting, default thresholds.

## ref+white

| SNR dB | exact / truth | wrong or extra bursts |
|---:|---:|---:|
| 30 | 56 / 56 (100%) | 0 |
| 20 | 56 / 56 (100%) | 0 |
| 15 | 56 / 56 (100%) | 0 |
| 12 | 55 / 56 (98%) | 1 |
| 9 | 56 / 56 (100%) | 0 |
| 6 | 53 / 56 (95%) | 3 |
| 3 | 39 / 56 (70%) | 17 |
| 0 | 15 / 56 (27%) | 41 |

## ref+band

| SNR dB | exact / truth | wrong or extra bursts |
|---:|---:|---:|
| 30 | 56 / 56 (100%) | 0 |
| 20 | 56 / 56 (100%) | 0 |
| 15 | 55 / 56 (98%) | 1 |
| 12 | 56 / 56 (100%) | 0 |
| 9 | 55 / 56 (98%) | 1 |
| 6 | 52 / 56 (93%) | 4 |
| 3 | 37 / 56 (66%) | 19 |
| 0 | 19 / 56 (34%) | 37 |

## syn+band

| SNR dB | exact / truth | wrong or extra bursts |
|---:|---:|---:|
| 30 | 32 / 32 (100%) | 0 |
| 20 | 32 / 32 (100%) | 0 |
| 15 | 32 / 32 (100%) | 0 |
| 12 | 32 / 32 (100%) | 0 |
| 9 | 32 / 32 (100%) | 0 |
| 6 | 32 / 32 (100%) | 0 |
| 3 | 32 / 32 (100%) | 0 |
| 0 | 32 / 32 (100%) | 0 |

Slowest single decode on this PC: 0.4 s (pure Python; the N95 is far slower).
