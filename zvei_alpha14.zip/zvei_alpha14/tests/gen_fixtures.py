"""PC-only fixture generator for the ZVEI decoder tests (never goes on the phone).

Usage: python gen_fixtures.py [output_dir]
Writes deterministic WAV fixtures. Never touches reference_audio/zvei.wav.
"""
import os
import struct
import sys
import wave

import numpy as np

ZVEI1 = {
    '0': 2400, '1': 1060, '2': 1160, '3': 1270, '4': 1400, '5': 1530,
    '6': 1670, '7': 1830, '8': 2000, '9': 2200,
    'A': 2800, 'B': 810, 'C': 970, 'D': 885, 'E': 2600, 'F': 680,
}
RATE = 8000


def tone(symbol, ms, amp=0.5, offset_pct=0.0, rate=RATE, ramp_ms=2.0):
    n = int(round(rate * ms / 1000.0))
    t = np.arange(n) / float(rate)
    freq = ZVEI1[symbol] * (1.0 + offset_pct / 100.0)
    x = amp * np.sin(2.0 * np.pi * freq * t)
    r = int(rate * ramp_ms / 1000.0)
    if r > 0 and 2 * r < n:
        ramp = 0.5 - 0.5 * np.cos(np.pi * np.arange(r) / r)
        x[:r] *= ramp
        x[-r:] *= ramp[::-1]
    return x


def call(seq, tone_ms=40, amp=0.5, offset_pct=0.0, gain_jitter=0.0, rng=None):
    parts = []
    for s in seq:
        a = amp
        if gain_jitter and rng is not None:
            a = amp * (1.0 - gain_jitter * rng.random())
        parts.append(tone(s, tone_ms, a, offset_pct))
    return np.concatenate(parts)


def recording(calls, total_s, tone_ms=40, amp=0.5, offset_pct=0.0,
              gain_jitter=0.0, seed=0):
    """calls: list of (start_seconds, sequence). Returns float array (-1..1)."""
    rng = np.random.RandomState(seed)
    x = np.zeros(int(total_s * RATE))
    for start, seq in calls:
        c = call(seq, tone_ms, amp, offset_pct, gain_jitter, rng)
        i = int(round(start * RATE))
        x[i:i + len(c)] += c[:len(x) - i]
    return x


def add_white_noise(x, snr_db, signal_rms, seed):
    rng = np.random.RandomState(seed)
    sigma = signal_rms / (10.0 ** (snr_db / 20.0))
    return x + rng.normal(0.0, sigma, len(x))


def add_band_noise(x, snr_db, signal_rms, seed, lo=300.0, hi=3000.0):
    """White noise band-limited to lo..hi Hz (radio audio like), set to snr_db."""
    rng = np.random.RandomState(seed)
    n = rng.normal(0.0, 1.0, len(x))
    spec = np.fft.rfft(n)
    freqs = np.fft.rfftfreq(len(n), 1.0 / RATE)
    spec[(freqs < lo) | (freqs > hi)] = 0.0
    n = np.fft.irfft(spec, len(x))
    n *= (signal_rms / (10.0 ** (snr_db / 20.0))) / np.sqrt(np.mean(n * n))
    return x + n


def write_wav(path, x):
    pcm = np.clip(np.round(x * 32767.0), -32768, 32767).astype('<i2')
    w = wave.open(path, 'wb')
    try:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
    finally:
        w.close()


def read_wav_float(path):
    w = wave.open(path, 'rb')
    try:
        n = w.getnframes()
        data = struct.unpack('<%dh' % n, w.readframes(n))
    finally:
        w.close()
    return np.array(data, dtype=float) / 32768.0


def standard_fixtures(outdir):
    """Write the deterministic fixture set; returns {name: expected_raw_list}."""
    os.makedirs(outdir, exist_ok=True)
    expected = {}

    def put(name, x, raws):
        write_wav(os.path.join(outdir, name), x)
        expected[name] = raws

    # Three clean 186 repeats, 40 ms.
    put('clean_186x3.wav',
        recording([(2.0, '186'), (2.55, '186'), (3.1, '186')], 6.0),
        ['186', '186', '186'])

    # Different five-tone calls (no identical adjacent digits).
    seqs = ['12345', '90817', '26485', '73951']
    put('five_tone_calls.wav',
        recording([(1.0 + 2.0 * i, s) for i, s in enumerate(seqs)], 10.0),
        seqs)

    # ZVEI repetition marker: raw 12E45 (E repeats the previous digit).
    put('e_repeat.wav', recording([(1.5, '12E45')], 5.0), ['12E45'])

    # Repeat grouping: three 186 close together, 186 again >3 s later (new
    # group), then a different ID.
    put('group_gaps.wav',
        recording([(1.0, '186'), (1.6, '186'), (2.2, '186'),
                   (6.5, '186'), (7.1, '186'), (8.8, '123')], 12.0),
        ['186', '186', '186', '186', '186', '123'])

    # Other tone lengths, decoded with the matching setting.
    for ms in (30, 50, 70, 100):
        put('dur_%d.wav' % ms,
            recording([(1.0, '13579'), (3.5, '02468')], 8.0, tone_ms=ms),
            ['13579', '02468'])

    # Amplitude variation and a frequency offset.
    put('jitter_amp.wav',
        recording([(1.0, '12345'), (3.0, '67890')], 6.0, gain_jitter=0.6,
                  seed=3), ['12345', '67890'])
    put('offset_plus1.wav',
        recording([(1.0, '12345'), (3.0, '67890')], 6.0, offset_pct=1.0),
        ['12345', '67890'])
    put('offset_minus15.wav',
        recording([(1.0, '12345'), (3.0, '67890')], 6.0, offset_pct=-1.5),
        ['12345', '67890'])

    # Many candidate runs, to exercise the 100-entry diagnostic cap.
    calls = []
    for i in range(32):
        calls.append((0.5 + i * 0.6, '1357902468'[(i % 2):(i % 2) + 5]))
    put('many_runs.wav', recording(calls, 21.0), [c[1] for c in calls])

    # Level cases.
    base = recording([(1.0, '186'), (1.6, '186')], 4.0)
    put('quiet.wav', base * 0.04, ['186', '186'])
    put('clipped.wav', np.clip(base * 4.0, -1.0, 1.0), ['186', '186'])
    return expected


if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'fixtures'
    exp = standard_fixtures(out)
    for k in sorted(exp):
        print(k, exp[k])
