# zvei_decoder.py
# ZVEI1 tone decoder for Nokia N95 / PyS60 1.4.5 (Python 2.2.2)
# Version 1.3 + status UI patch: run-based decoder with visible processing stages.
# Also runs on modern Python 3 for PC testing.
# Pure Python: no NumPy or other third-party modules.
#
# Phone: records microphone audio to WAV, then decodes it.
# PC:    python zvei_decoder.py file.wav [tone_ms]
#
# The default tone length is deliberately 40 ms for the user's local taxi
# radio system. Change it in the phone menu only when testing another system.

import math
import struct
import os
import sys
import time

# ZVEI1 tone allocation. Keep the 885 Hz entry as in the original script.
ZVEI1 = {
    '0': 2400, '1': 1060, '2': 1160, '3': 1270, '4': 1400, '5': 1530,
    '6': 1670, '7': 1830, '8': 2000, '9': 2200,
    'A': 2800, 'B': 810, 'C': 970, 'D': 885, 'E': 2600, 'F': 680,
}
SYMS = '0123456789ABCDEF'
DEFAULT_TONE_MS = 40
DEFAULT_RECORD_SECS = 10
MAX_HISTORY = 50
MAX_SIGNAL_LOG = 100

# Signal-quality thresholds. Frame candidates are retained at low purity so
# borderline tones can be reviewed. A complete tone run must then pass the
# stricter average thresholds below. Percentages are stored in RAM for review.
FRAME_MIN_PURITY = 12.0       # per-frame candidate floor, percent
FRAME_MIN_MATCH = 50.0        # per-frame winner-vs-runner-up, percent
RUN_MIN_PURITY = 18.0         # average purity required for a tone run
RUN_MIN_MATCH = 75.0          # average match required for a tone run

# Volatile call history: cleared automatically when the program exits.
# Each entry is (timestamp, offset, decoded, raw, tone_ms, wav_seconds, rate).
CALL_HISTORY = []

# Diagnostics from the most recently decoded WAV. Each entry records both
# accepted and rejected candidate runs. This is RAM-only and is reset each decode.
LAST_SIGNAL_LOG = []
LAST_BURST_DIAGNOSTICS = []

# Nominal ZVEI transmitters can be slightly off frequency. Search limits
# are applied only to the two strongest nominal candidates, keeping the
# extra CPU work modest for the N95.
FREQ_LOW_TOL = 0.015       # -1.5 percent
FREQ_HIGH_TOL = 0.010      # +1.0 percent



def read_wav(path):
    """Read uncompressed 8-bit or 16-bit PCM WAV; use the first channel."""
    f = open(path, 'rb')
    try:
        data = f.read()
    finally:
        f.close()

    riff = 'RIFF'.encode('ascii')
    wave = 'WAVE'.encode('ascii')
    fmt_id = 'fmt '.encode('ascii')
    data_id = 'data'.encode('ascii')

    if len(data) < 12 or data[0:4] != riff or data[8:12] != wave:
        raise ValueError('not a RIFF/WAVE file')

    pos = 12
    fmt = None
    pcm = None
    data_len = len(data)

    while pos + 8 <= data_len:
        cid = data[pos:pos + 4]
        size = struct.unpack('<I', data[pos + 4:pos + 8])[0]
        chunk_start = pos + 8
        chunk_end = chunk_start + size

        if cid == fmt_id:
            if size < 16 or chunk_end > data_len:
                raise ValueError('invalid WAV fmt chunk')
            fmt = struct.unpack('<HHIIHH', data[chunk_start:chunk_start + 16])
        elif cid == data_id:
            # Some recorders leave a zero/oversized data length in an
            # interrupted recording. In that case, use the bytes present.
            if size == 0 or chunk_end > data_len:
                pcm = data[chunk_start:]
            else:
                pcm = data[chunk_start:chunk_end]
            break

        # WAV chunks are padded to an even byte boundary.
        if chunk_end > data_len:
            break
        pos = chunk_end + (size & 1)

    if fmt is None or pcm is None:
        raise ValueError('WAV has no usable fmt/data chunk')

    tag, channels, rate, byte_rate, block_align, bits = fmt

    # Only ordinary PCM is accepted. WAVE_FORMAT_EXTENSIBLE is deliberately
    # not guessed at: interpreting a non-PCM subformat as PCM gives bad data.
    if tag != 1:
        raise ValueError('WAV format tag %d is not standard PCM' % tag)
    if channels < 1:
        raise ValueError('WAV has invalid channel count')
    if rate <= 0:
        raise ValueError('WAV has invalid sample rate')
    if bits != 8 and bits != 16:
        raise ValueError('unsupported WAV bit depth %d (use 8-bit or 16-bit PCM)' % bits)

    bytes_per_sample = bits // 8
    frame_bytes = bytes_per_sample * channels
    if frame_bytes <= 0 or block_align != frame_bytes:
        raise ValueError('WAV has invalid block alignment')

    frame_count = len(pcm) // frame_bytes
    if frame_count <= 0:
        raise ValueError('WAV contains no audio samples')

    usable_length = frame_count * frame_bytes
    if usable_length < len(pcm):
        pcm = pcm[:usable_length]

    # Release the full WAV byte string before building the sample array; this
    # matters on the N95 where memory is limited.
    del data

    if bits == 16:
        values = struct.unpack('<%dh' % (frame_count * channels), pcm)
        if channels == 1:
            # A tuple is directly indexable by Goertzel and avoids making a
            # second large list of Python integer references.
            samples = values
        else:
            samples = []
            i = 0
            while i < len(values):
                samples.append(values[i])
                i += channels
            del values
    else:
        values = struct.unpack('%dB' % (frame_count * channels), pcm)
        samples = []
        i = 0
        while i < len(values):
            samples.append((values[i] - 128) * 256)
            i += channels
        del values

    del pcm
    return samples, rate


def _goertzel(x, start, count, coeff, mean_value):
    """Goertzel power with per-frame DC removal."""
    s1 = 0.0
    s2 = 0.0
    end = start + count
    i = start
    while i < end:
        s0 = (x[i] - mean_value) + coeff * s1 - s2
        s2 = s1
        s1 = s0
        i += 1
    power = s1 * s1 + s2 * s2 - coeff * s1 * s2
    if power < 0.0:
        power = 0.0
    return power


def _make_coeffs(rate):
    coeffs = []
    i = 0
    while i < len(SYMS):
        freq = ZVEI1[SYMS[i]]
        coeffs.append(2.0 * math.cos(2.0 * math.pi * freq / rate))
        i += 1
    return coeffs


def _candidate_power(samples, start, win, mean_value, rate, symbol):
    """Return the strongest Goertzel power near one nominal ZVEI frequency."""
    freq = ZVEI1[symbol]
    low = freq * (1.0 - FREQ_LOW_TOL)
    high = freq * (1.0 + FREQ_HIGH_TOL)
    c_low = 2.0 * math.cos(2.0 * math.pi * low / rate)
    c_nom = 2.0 * math.cos(2.0 * math.pi * freq / rate)
    c_high = 2.0 * math.cos(2.0 * math.pi * high / rate)
    p_low = _goertzel(samples, start, win, c_low, mean_value)
    p_nom = _goertzel(samples, start, win, c_nom, mean_value)
    p_high = _goertzel(samples, start, win, c_high, mean_value)
    if p_nom > p_low:
        p_low = p_nom
    if p_high > p_low:
        p_low = p_high
    return p_low


def _frame_energy(samples, start, win):
    total = 0.0
    squares = 0.0
    end = start + win
    i = start
    while i < end:
        value = samples[i]
        total += value
        squares += value * value
        i += 1
    mean_value = total / float(win)
    energy = squares - win * mean_value * mean_value
    if energy < 0.0:
        energy = 0.0
    return mean_value, energy


def _expand_repetition(seq):
    """Expand ZVEI1 E repetition markers for display, preserving raw elsewhere."""
    expanded = ''
    previous = None
    i = 0
    while i < len(seq):
        symbol = seq[i]
        if symbol == 'E' and previous is not None:
            expanded += previous
        else:
            expanded += symbol
            if symbol != 'E':
                previous = symbol
        i += 1
    return expanded


def decode(samples, rate, tone_ms=DEFAULT_TONE_MS, progress=None):
    """Decode ZVEI1 bursts and retain per-tone quality diagnostics in RAM.

    A frame is retained as a candidate at a deliberately permissive threshold.
    Candidate runs are accepted only after checking their average purity,
    average winner/runner-up match percentage and duration. This allows a
    distorted first tone to survive without accepting isolated noise frames.
    """
    global LAST_SIGNAL_LOG, LAST_BURST_DIAGNOSTICS
    LAST_SIGNAL_LOG = []
    LAST_BURST_DIAGNOSTICS = []

    if tone_ms < 30 or tone_ms > 200:
        raise ValueError('tone length must be between 30 and 200 ms')
    if rate <= 0:
        raise ValueError('invalid sample rate')
    if rate / 2.0 <= 2800.0 * (1.0 + FREQ_HIGH_TOL):
        raise ValueError('sample rate too low for the 2800 Hz ZVEI1 tone')

    sample_count = len(samples)
    win_ms = min(tone_ms / 2.0, 25.0)
    win = int(rate * win_ms / 1000.0)
    step = max(1, int(rate * 0.010))
    if win < 8:
        raise ValueError('sample rate or analysis window is too small')

    minrun = max(2, int((tone_ms - win_ms) / 10.0) - 1)
    gap_frames = max(3, int(tone_ms * 1.5 / 10.0))
    coeffs = _make_coeffs(rate)

    starts = range(0, sample_count - win + 1, step)
    if len(starts) == 0:
        return []

    # First pass: frame energy and DC mean.
    means = []
    energies = []
    k = 0
    while k < len(starts):
        mean_value, energy = _frame_energy(samples, starts[k], win)
        means.append(mean_value)
        energies.append(energy)
        k += 1

    maximum_energy = max(energies)
    if maximum_energy <= 0.0:
        return []
    gate = maximum_energy * 0.001

    # Retain candidate symbol and quality metrics for every useful frame.
    frame_symbols = []
    frame_purity = []
    frame_match = []
    total_frames = len(starts)
    k = 0
    while k < total_frames:
        energy = energies[k]
        symbol = None
        purity_percent = 0.0
        match_percent = 0.0

        if energy > gate and energy > 0.0:
            powers = []
            j = 0
            while j < len(coeffs):
                powers.append(_goertzel(samples, starts[k], win,
                                        coeffs[j], means[k]))
                j += 1

            best_index = powers.index(max(powers))
            second_index = -1
            second_power = 0.0
            j = 0
            while j < len(powers):
                if j != best_index and powers[j] > second_power:
                    second_power = powers[j]
                    second_index = j
                j += 1

            best_power = powers[best_index]
            nominal_purity = best_power / (energy * win / 2.0)
            nominal_ratio = best_power / max(second_power, 1.0)

            # Refine only the two strongest symbol candidates around their
            # nominal frequencies. Keep the winning symbol attached to its
            # own refined power, even if the runner-up becomes stronger.
            if nominal_ratio < 3.0 or nominal_purity < 0.85:
                first_power = _candidate_power(
                    samples, starts[k], win, means[k], rate, SYMS[best_index])
                if second_index >= 0:
                    second_refined = _candidate_power(
                        samples, starts[k], win, means[k], rate,
                        SYMS[second_index])
                else:
                    second_refined = 0.0

                if second_refined > first_power:
                    old_index = best_index
                    old_power = first_power
                    best_index = second_index
                    best_power = second_refined
                    second_power = old_power
                    second_index = old_index
                else:
                    best_power = first_power
                    second_power = second_refined

            denominator = energy * win / 2.0
            if denominator > 0.0:
                purity_percent = 100.0 * best_power / denominator
            if purity_percent > 100.0:
                purity_percent = 100.0
            if best_power + second_power > 0.0:
                match_percent = (100.0 * best_power /
                                 (best_power + second_power))

            # A candidate can be logged even when the eventual tone run fails.
            if (purity_percent >= FRAME_MIN_PURITY and
                    match_percent >= FRAME_MIN_MATCH):
                symbol = SYMS[best_index]

        frame_symbols.append(symbol)
        frame_purity.append(purity_percent)
        frame_match.append(match_percent)
        if progress is not None and k % 50 == 0:
            progress(k, total_frames)
        k += 1

    # Group candidate frames into tone runs. Short gaps are allowed because
    # a frame straddling a tone boundary may be classified as undecided.
    runs = []
    idx = 0
    while idx < len(frame_symbols):
        symbol = frame_symbols[idx]
        if symbol is not None:
            if runs and runs[-1][0] == symbol and idx - runs[-1][3] <= 3:
                run = runs[-1]
                run[1] += 1
                run[3] = idx
                run[4] += frame_purity[idx]
                run[5] += frame_match[idx]
                if frame_purity[idx] > run[6]:
                    run[6] = frame_purity[idx]
                if frame_match[idx] < run[7]:
                    run[7] = frame_match[idx]
            else:
                runs.append([symbol, 1, idx, idx,
                             frame_purity[idx], frame_match[idx],
                             frame_purity[idx], frame_match[idx]])
        idx += 1

    accepted_runs = []
    diagnostic_runs = []
    i = 0
    while i < len(runs):
        run = runs[i]
        count = run[1]
        average_purity = run[4] / float(count)
        average_match = run[5] / float(count)
        accepted = True
        reasons = []

        if count < minrun:
            accepted = False
            reasons.append('short run')
        if average_purity < RUN_MIN_PURITY:
            accepted = False
            reasons.append('low purity')
        if average_match < RUN_MIN_MATCH:
            accepted = False
            reasons.append('weak match')

        if accepted:
            reason = 'accepted'
            accepted_runs.append(run)
        else:
            reason = ', '.join(reasons)

        start_offset = starts[run[2]] / float(rate)
        end_offset = (starts[run[3]] + win) / float(rate)
        diagnostic = (start_offset, end_offset, run[0],
                      average_purity, run[6], average_match, run[7],
                      count, accepted, reason, run[2], run[3])
        diagnostic_runs.append(diagnostic)
        i += 1

    # Store all candidate runs (accepted and rejected) in a bounded RAM log.
    LAST_SIGNAL_LOG = diagnostic_runs[-MAX_SIGNAL_LOG:]

    # Only accepted tone runs form decoded calls.
    bursts = []
    current = []
    i = 0
    while i < len(accepted_runs):
        run = accepted_runs[i]
        if current and (run[2] - current[-1][3]) > gap_frames:
            bursts.append(current)
            current = []
        current.append(run)
        i += 1
    if current:
        bursts.append(current)

    output = []
    LAST_BURST_DIAGNOSTICS = []
    i = 0
    while i < len(bursts):
        burst = bursts[i]
        sequence = ''
        j = 0
        while j < len(burst):
            sequence += burst[j][0]
            j += 1

        first_index = burst[0][2]
        last_index = burst[-1][3]
        start_seconds = starts[first_index] / float(rate)
        output.append((start_seconds, sequence))

        # Include rejected candidates immediately around this burst. This is
        # useful for spotting spurious edge tones in the Signal quality log.
        burst_log = []
        j = 0
        while j < len(diagnostic_runs):
            diagnostic = diagnostic_runs[j]
            if (diagnostic[10] <= last_index + gap_frames and
                    diagnostic[11] >= first_index - gap_frames):
                burst_log.append(diagnostic)
            j += 1
        LAST_BURST_DIAGNOSTICS.append(burst_log)
        i += 1

    if progress is not None:
        progress(total_frames, total_frames)
    return output


def decode_file(path, tone_ms=DEFAULT_TONE_MS, progress=None):
    samples, rate = read_wav(path)
    return decode(samples, rate, tone_ms, progress), len(samples) / float(rate), rate


def format_result(bursts):
    if not bursts:
        return 'No ZVEI1 tones found'
    lines = []
    i = 0
    while i < len(bursts):
        start_time, raw_sequence = bursts[i]
        expanded = _expand_repetition(raw_sequence)
        if expanded != raw_sequence:
            lines.append('%.2fs  %s  (raw: %s)' %
                         (start_time, expanded, raw_sequence))
        else:
            lines.append('%.2fs  %s' % (start_time, raw_sequence))
        i += 1
    return '\n'.join(lines)


# ---------------------------------------------------------------- phone UI
try:
    import appuifw
    import audio
    import e32
    ON_PHONE = True
except ImportError:
    ON_PHONE = False


def _wav_path():
    if os.path.isdir(u'E:\\'):
        return u'E:\\zvei.wav'
    if os.path.isdir(u'C:\\Data'):
        return u'C:\\Data\\zvei.wav'
    raise IOError('Neither E:\\ nor C:\\Data is available')


def _set_phone_status(label):
    """Refresh the PyS60 title so the current processing stage is visible."""
    try:
        appuifw.app.title = label
        e32.ao_yield()
    except Exception:
        pass


def _record(path, secs):
    if secs < 1 or secs > 20:
        raise ValueError('recording length must be between 1 and 20 seconds')
    if os.path.exists(path):
        os.remove(path)

    snd = None
    try:
        snd = audio.Sound.open(path)
        snd.record()
        left = secs
        while left > 0:
            appuifw.app.title = u'REC %d' % left
            e32.ao_sleep(1)
            left -= 1
    finally:
        if snd is not None:
            _set_phone_status(u'STOPPING RECORDING')
            try:
                snd.stop()
            except Exception:
                pass
            _set_phone_status(u'RECORDING STOPPED')
            _set_phone_status(u'CLOSING WAV')
            try:
                snd.close()
            except Exception:
                pass
        _set_phone_status(u'WAV READY')


def _timestamp_text(value):
    """Format a local timestamp using functions available on old PyS60."""
    try:
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(value))
    except Exception:
        return 'time unavailable'


def _add_to_history(bursts, recorded_at, tone_ms, duration, rate):
    """Store decoded calls in RAM only; never write decoded results to disk."""
    global CALL_HISTORY
    i = 0
    while i < len(bursts):
        offset, raw_sequence = bursts[i]
        decoded_sequence = _expand_repetition(raw_sequence)
        call_time = recorded_at + offset
        diagnostics = []
        if i < len(LAST_BURST_DIAGNOSTICS):
            diagnostics = LAST_BURST_DIAGNOSTICS[i]
        entry = (_timestamp_text(call_time), offset, decoded_sequence,
                 raw_sequence, tone_ms, duration, rate, diagnostics)
        CALL_HISTORY.insert(0, entry)
        i += 1

    # Bound memory usage on the N95. The newest 50 calls are retained.
    while len(CALL_HISTORY) > MAX_HISTORY:
        del CALL_HISTORY[-1]


def _decode_ui(path, tone_ms, recorded_at=None):
    current_stage = u'READING WAV'

    def prog(k, total):
        appuifw.app.title = u'DECODING %d%%' % (100 * k // max(total, 1))
        e32.ao_yield()

    try:
        _set_phone_status(u'READING WAV')
        samples, rate = read_wav(path)
        duration = len(samples) / float(rate)

        _set_phone_status(u'DECODING')
        current_stage = u'DECODING'
        bursts = decode(samples, rate, tone_ms, prog)
        del samples
    except Exception:
        appuifw.app.title = u'ZVEI1'
        error_value = sys.exc_info()[1]
        appuifw.note(u'%s error: %s' %
                     (current_stage, unicode(str(error_value))), 'error')
        return

    appuifw.app.title = u'ZVEI1'

    # For a newly recorded file, use recording start time. For an older WAV,
    # use its modification time; fall back to the current time if unavailable.
    if recorded_at is None:
        try:
            # File mtime is normally close to recording completion, so move
            # back by the WAV duration to estimate when recording began.
            recorded_at = os.path.getmtime(path) - duration
        except Exception:
            recorded_at = time.time()

    _add_to_history(bursts, recorded_at, tone_ms, duration, rate)

    result_text = format_result(bursts)
    result_text += '\n(%.1fs @ %d Hz, ZVEI-1 / %d ms)' % (duration, rate, tone_ms)
    if bursts:
        result_text += '\nAdded %d call(s) to memory history.' % len(bursts)
    else:
        result_text += '\nNo calls added to memory history.'
    result_text += '\nOpen Signal quality log for purity/match scores.'

    # Decoded calls are deliberately NOT saved or logged to a file.
    appuifw.note(unicode(result_text), 'info')


def _show_history():
    if not CALL_HISTORY:
        appuifw.note(u'No calls in memory.\nHistory is cleared when ZVEI1 exits.', 'info')
        return

    labels = []
    i = 0
    while i < len(CALL_HISTORY):
        entry = CALL_HISTORY[i]
        stamp = entry[0]
        # Keep the list compact enough for the N95 screen; full date is in Details.
        labels.append(u'%s  %s' % (stamp[5:16], entry[2]))
        i += 1

    selected = appuifw.popup_menu(labels, u'Call history (newest first)')
    if selected is None:
        return

    entry = CALL_HISTORY[selected]
    details = (u'Call: %s\n' % entry[2] +
               u'Raw tones: %s\n' % entry[3] +
               u'Date/time: %s\n' % entry[0] +
               u'Position in WAV: %.2f s\n' % entry[1] +
               u'Profile: ZVEI-1, %d ms\n' % entry[4] +
               u'Recording: %.1f s\n' % entry[5] +
               u'Sample rate: %d Hz\n' % entry[6] +
               u'Tones detected: %d' % len(entry[3]))
    diagnostics = entry[7]
    if diagnostics:
        details += u'\n\nSIGNAL QUALITY (RAM)'
        i = 0
        while i < len(diagnostics):
            item = diagnostics[i]
            if item[8]:
                status = u'OK'
            else:
                status = u'REJECT: %s' % item[9]
            details += (u'\n%.2fs %s P%.0f%% M%.0f%% %s' %
                        (item[0], item[2], item[3], item[5], status))
            i += 1
    appuifw.note(details, 'info')


def _show_signal_log():
    """Show candidate purity/match diagnostics from the last decoded WAV."""
    if not LAST_SIGNAL_LOG:
        appuifw.note(u'No signal measurements in memory. Decode a WAV first.', 'info')
        return

    labels = []
    i = 0
    while i < len(LAST_SIGNAL_LOG):
        item = LAST_SIGNAL_LOG[i]
        if item[8]:
            status = u'OK'
        else:
            status = u'NO'
        labels.append(u'%.2fs %s P%.0f M%.0f %s' %
                      (item[0], item[2], item[3], item[5], status))
        i += 1

    selected = appuifw.popup_menu(labels, u'Signal quality log (RAM)')
    if selected is None:
        return

    item = LAST_SIGNAL_LOG[selected]
    if item[8]:
        result = u'ACCEPTED'
    else:
        result = u'REJECTED: %s' % item[9]
    details = (u'Candidate: %s\n' % item[2] +
               u'Result: %s\n' % result +
               u'Start: %.3f s\n' % item[0] +
               u'End: %.3f s\n' % item[1] +
               u'Average purity: %.1f%%\n' % item[3] +
               u'Maximum purity: %.1f%%\n' % item[4] +
               u'Average match: %.1f%%\n' % item[5] +
               u'Lowest match: %.1f%%\n' % item[6] +
               u'Frames: %d\n' % item[7] +
               u'\nPurity = tone energy / total frame energy.\n' +
               u'Match = winning tone / (winner + runner-up).')
    appuifw.note(details, 'info')


def _show_decoder_info(tone_ms, secs):
    info = (u'ZVEI-1 decoder\n' +
            u'Tone length: %d ms\n' % tone_ms +
            u'Recording length: %d s\n' % secs +
            u'Calls in memory: %d / %d\n' % (len(CALL_HISTORY), MAX_HISTORY) +
            u'Quality entries: %d / %d\n' % (len(LAST_SIGNAL_LOG), MAX_SIGNAL_LOG) +
            u'History and quality log are RAM only.\n' +
            u'History is cleared when the app exits.\n' +
            u'Decoded results are not written to files.')
    appuifw.note(info, 'info')


def _clear_history():
    global CALL_HISTORY
    if not CALL_HISTORY and not LAST_SIGNAL_LOG:
        appuifw.note(u'Call history and signal log are already empty', 'info')
        return
    answer = appuifw.query(u'Clear calls and signal log from memory?', 'query')
    if answer:
        CALL_HISTORY = []
        LAST_SIGNAL_LOG[:] = []
        LAST_BURST_DIAGNOSTICS[:] = []
        appuifw.note(u'Memory history and signal log cleared', 'info')


def _get_number(prompt, current, minimum, maximum):
    value = appuifw.query(prompt, 'number', current)
    if value is None:
        return current
    try:
        value = int(value)
    except Exception:
        appuifw.note(u'Please enter a whole number', 'error')
        return current
    if value < minimum or value > maximum:
        appuifw.note(u'Enter a value from %d to %d' % (minimum, maximum), 'error')
        return current
    return value


def main():
    appuifw.app.title = u'ZVEI1'
    tone_ms = DEFAULT_TONE_MS
    secs = DEFAULT_RECORD_SECS

    while True:
        items = [u'Record + decode', u'Decode last WAV',
                 u'Call history (%d)' % len(CALL_HISTORY),
                 u'Signal quality log (%d)' % len(LAST_SIGNAL_LOG), u'Clear call history',
                 u'Tone ms: %d' % tone_ms,
                 u'Record secs: %d' % secs,
                 u'Decoder information', u'Exit']
        choice = appuifw.popup_menu(items, u'ZVEI1 decoder')
        if choice is None or choice == 8:
            break

        if choice == 2:
            _show_history()
            continue
        elif choice == 3:
            _show_signal_log()
            continue
        elif choice == 4:
            _clear_history()
            continue
        elif choice == 5:
            tone_ms = _get_number(u'Tone length ms (40 for taxi test)',
                                  tone_ms, 30, 200)
            continue
        elif choice == 6:
            secs = _get_number(u'Recording seconds (1-20)', secs, 1, 20)
            continue
        elif choice == 7:
            _show_decoder_info(tone_ms, secs)
            continue

        try:
            path = _wav_path()
        except Exception:
            appuifw.note(u'No usable C: or E: storage directory', 'error')
            continue

        if choice == 0:
            recording_started = time.time()
            try:
                _record(path, secs)
            except Exception:
                appuifw.app.title = u'ZVEI1'
                error_value = sys.exc_info()[1]
                appuifw.note(u'Record failed: %s' % unicode(str(error_value)), 'error')
                continue
            _decode_ui(path, tone_ms, recording_started)
        elif choice == 1:
            _decode_ui(path, tone_ms)


if ON_PHONE:
    main()
elif __name__ == '__main__' and len(sys.argv) > 1:
    tone_length = DEFAULT_TONE_MS
    if len(sys.argv) > 2:
        tone_length = int(sys.argv[2])
    decoded, duration, sample_rate = decode_file(sys.argv[1], tone_length)
    print(format_result(decoded))
    print('(%.1fs @ %d Hz)' % (duration, sample_rate))
